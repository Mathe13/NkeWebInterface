#include "../Kernel/kernel.h"
int buffer=0;
void t0(){
	printk("teste 123",buffer);
	taskexit();
}

int main (int argc, char *argv[])
{
  int task0;
  taskcreate(&t0,task0);
  start(RR);
}
